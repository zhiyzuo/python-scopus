import os.path
from pyscopus.scopus import Scopus
from pkg_resources import get_distribution, DistributionNotFound

__version__ = '1.0.0a1'
